﻿
// для запуска примера - необходимо раскоментировать соответствующие файлы с текстом примера и вызов примера \
номера тестов соответствуют номерам заданий \
исходные тексты примеров написаны в соответствии стандарту языка Си/C++, для перевода к стандарту язвка Си необходимо заменить потоковые ввод-вывод (cin, cout соответственно) на функции стандартных ввода-вывода (scanf, printf соответственно)

//#include "./sources/test1.cpp"
//#include "./sources/test2.cpp"
//#include "./sources/test3.cpp"
//#include "./sources/test4.cpp"
//#include "./sources/test5.cpp"
//#include "./sources/test6.cpp"
//#include "./sources/test7.cpp"
//#include "./sources/test8.cpp"
//#include "./sources/test9.cpp"
//#include "./sources/test10.cpp"
//#include "./sources/test11.cpp"
//#include "./sources/test12.cpp"
//#include "./sources/test13.cpp"
//#include "./sources/test14.cpp"
//#include "./sources/test15.cpp"

int main()
{
	//return test1();
	//return test2();
	//return test3();
	//return test4();
	//return test5();
	//return test6();
	//return test7();
	//return test8();
	//return test9();
	//return test10();
	//return test11();
	//return test12();
	//return test13();
	//return test14();
	//return test15();
}
