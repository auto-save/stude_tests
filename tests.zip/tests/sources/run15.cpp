//������� 15 - �������� ����� �����������

#include "run15.h"

#include <Windows.h>

extern HANDLE console;

void imi(point writepoint); //imitation of input symbol
void out(point readpoint); //gettin output symbol
void desh(word* arr); //shift delay buffer

bool run(delay* arg) {
	for (int i = 0; i < LENBUF; ++i)
	{
		imi(arg->startpoint);
		desh(arg->buf);
	}
	for (int i = 0; i < LENBUF; ++i)
	{
		out(arg->endpoint);
		desh(arg->buf);
	}
	return true;
}

void imi(point writepoint) {
	//Sleep(1000 / LENBUF);
	*writepoint = rand() % 100;
}

void out(point readpoint) {
	//Sleep(1000 / LENBUF);
	SetConsoleTextAttribute(console, 10);
	cout << *readpoint << " ";
}

void desh(word* arr) {
	for (int j = LENBUF - 1; j > 0; --j) {
		Sleep(1000 / LENBUF);
		arr[j] = arr[j - 1];
	}
}