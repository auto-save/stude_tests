#ifndef TYPES15_H_
#define TYPES15_H_

#ifndef LENBUF
#define LENBUF 10 //length of delay buffer
#endif

typedef int word; //type of symbol in buffer
typedef int* point; //type of enumerate in buffer

typedef struct {
	point startpoint;
	point endpoint;
	word buf[LENBUF];
} delay; //type of delay buffer

static void init(delay* obj) {
	obj->startpoint = &obj->buf[0];
	obj->endpoint = &obj->buf[LENBUF - 1];
}

#endif //TYPES15_H_