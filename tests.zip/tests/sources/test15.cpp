// test 15 source

#include <iostream>
using namespace std;

#include "types15.h"
#include "run15.h"
#include "run15.cpp"

#include <Windows.h>
#include <ctime>

HANDLE console = GetStdHandle(STD_OUTPUT_HANDLE);

int test15()
{
	//start timer
	int start = clock();

	//create object of delay buffer
	delay buffer;
	init(&buffer);

	//start delay process
	if (!run(&buffer))
		return 1;

	//stop timer
	int end = clock();
	int time = end - start;
	SetConsoleTextAttribute(console, 12);
	cout << "\n execution time is " << time / 1000 << "s" << endl;
	SetConsoleTextAttribute(console, 7);

	return 0;
}
