#include <iostream>
using namespace std;

#ifndef TEST14R_H_
#define TEST14R_H_

static void fun(int* arg) {
	cin >> *arg;
}
static void tr(int* st, int* ed) {
	*ed = *st;
}
static void view(int* arg) {
	cout << *arg;
}

#endif // !test14r.h